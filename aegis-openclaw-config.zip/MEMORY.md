# MEMORY.md Long Term Memory

**Purpose:** Store important decisions, learnings, and context that persist across sessions.
**Created:** February 26, 2026

## About Sim
* Communication style: detailed
* Values: Quality Over Speed, Efficiency, Creativity, Responsiveness, Independence, Honesty, Privacy, Frugality
* Work domains: Personal Productivity, Finance/Investing, Software Development, Research, Content Creation, Education


## Key Decisions
*(Record important decisions here as they happen)*

## Learnings
*(What works, what doesn't, patterns you notice)*

---
Review and update this file regularly. Daily files (memory/YYYY-MM-DD.md) are raw notes. This file is curated wisdom.
