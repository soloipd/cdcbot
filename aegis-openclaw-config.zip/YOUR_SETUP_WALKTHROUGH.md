# Your Setup Walkthrough

Welcome, Sim! Here's how to get **Aegis** up and running.

> **Estimated time:** 5 to 10 minutes

## Step 1: Install OpenClaw

**macOS or Linux:**
```bash
curl -fsSL https://openclaw.ai/install.sh | bash
```

**Windows (PowerShell):**
```powershell
iwr -useb https://openclaw.ai/install.ps1 | iex
```

## Step 2: Run OpenClaw Setup

```bash
openclaw setup
```

This wizard handles model and auth setup, creates your workspace at `~/.openclaw/workspace`, configures the gateway, connects channels, installs the daemon (LaunchAgent on macOS or systemd on Linux), runs a health check, and offers skills.

> **If you used the installer in Step 1**, it already launches setup. You can skip this step.

## Step 3: Copy Your Config Files

Copy the files from this download into `~/.openclaw/workspace/`. You should have:
* `SOUL.md` for your agent's personality
* `AGENTS.md` for how it operates
* `USER.md` for your preferences
* `SECURITY.md` for safety rules
* `HEARTBEAT.md` for background checks and tasks
* `MEMORY.md` for long term memory starter
* `memory/YYYY-MM-DD.md` for daily notes
* `TOOLS.md` for local tools and integrations
* `OPENCLAW_CONFIG_SNIPPET.json5` for multi-agent routing (`agents.list` and ordered `bindings`) and safety defaults
* `SECURITY_AUDIT.md` for one-command security checks
* `OPENCLAW_SETUP_MISTAKES.md` for common setup failures and prevention checklist
* `scripts/run-security-audit.ps1` and `scripts/run-security-audit.sh` for one-click auditing
* `YOUR_SETUP_WALKTHROUGH.md` for this guide (optional, it does not need to live in the workspace)

## Step 3b: Apply Multi-Agent Routing (if enabled)

If you selected a multi-agent template, merge `OPENCLAW_CONFIG_SNIPPET.json5` into `~/.openclaw/openclaw.json`.

OAuth/token note: each agent stores its own channel/model credentials under its own `agentDir` (including `auth-profiles.json`). Do not share `agentDir` folders between agents, or you will get session/auth collisions.
Then run:

```bash
openclaw update
openclaw doctor --fix
openclaw security audit
```

## Step 4: Verify It Works

The gateway should already be running after setup. Verify:

```bash
openclaw status
openclaw gateway status
openclaw dashboard
```

Or just send a message on your configured channel and confirm Aegis replies.




## Step 5 (optional): Reconfigure Later

The setup wizard already handled model/auth and channel setup. If you want to change things later:

```bash
openclaw configure
```

If you skipped channels during setup, you can add them anytime. Your current selection is: Telegram


1. **Connect Telegram**
   1. Open Telegram and search for **@BotFather**
   2. Start a chat and type `/newbot`
   3. Follow the prompts and pick a display name and a username (must end in "bot")
   4. BotFather will give you a **bot token** (looks like `123456:ABCDEF...`)
   5. In your terminal, run the OpenClaw channel add flow and follow the prompts for Telegram
   6. Send a message to your new bot in Telegram. Aegis will reply

   > **Note:** First DM uses pairing by default. Approve the pairing code when prompted, or set `dmPolicy` in your config.


## Verify It Works

When you run `openclaw status`, you should see:
```
* Gateway running
* Connected to [your AI provider]
* Channels: Telegram
```

Now send a test message to Aegis on Telegram. You should get a reply within a few seconds.

**What success looks like:**
* Aegis responds with its personality from SOUL.md
* It knows its name, your name, and its boundaries
* It follows the communication style you configured (detailed)

## Troubleshooting

**"Command not found: openclaw"**
-> Run the install command again. On Mac, you may need to restart Terminal.

**"No API key found"**
-> Re-run `openclaw configure` (or `openclaw configure --section models`) and complete model/auth setup.

**"Channel connection failed"**
-> Re-run `openclaw configure --section channels` and follow the prompts. For Telegram, make sure you copied the FULL token from BotFather. For plugin channels (for example Twilio or Microsoft Teams), confirm the plugin is installed before re-running channel setup.

**Agent responds but ignores SOUL.md**
-> Make sure your config files are in `~/.openclaw/workspace`. Run `ls ~/.openclaw/workspace` to verify SOUL.md, AGENTS.md, etc. are there.

**High API costs**
-> Consider using a subscription plan instead of API keys. Check `/status` in your chat to see token usage.

## What's Next?

* Talk to Aegis through your configured channels
* Customize `SOUL.md` to refine your agent's personality
* Add skills and tools as needed
* Check the [OpenClaw docs](https://docs.openclaw.ai) for advanced configuration

Enjoy your new agent!
