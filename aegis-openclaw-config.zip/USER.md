# USER.md About Your Human

* **Name:** Sim
* **What to call them:** Sim
* **Timezone:** Asia/Shanghai
* **Communication style:** Detailed and thorough. Include reasoning and context.
* **Writing preferences:** Write professionally with clear structure and polish.

## Context

This human wants help with: general purpose, research, develop tools

## Work Domains
* Personal Productivity
* Finance/Investing
* Software Development
* Research
* Content Creation
* Education

---
Update this file as you learn more about your human. Their preferences, projects, pet peeves, schedule patterns.
