# TOOLS.md

This file is your local tools cheat sheet.
Keep it short and update it as you learn new details.

## Local Apps

* Email client and account names
* Calendar app and default calendar
* Notes or task app you prefer

## Command Line

* Common commands you use often
* Paths to important repos or scripts
* Safe commands that are ok to run without asking

## APIs and Services

* List service names you use often
* Store tokens in environment variables, not here
* Note any rate limits or spend caps

## Messaging

* Primary channel to reach Sim
* Backup channel for urgent issues
* Any known quiet hours or do not disturb windows
