# SECURITY_AUDIT.md

This bundle includes a conservative safety baseline, but you should still run OpenClaw's built-in audits after install.

Note: the generated routing snippet targets channels with known IDs from your selection. Some plugin-backed channels still need plugin install and provider auth before routing is fully active.

## One-Command Checks

```bash
openclaw update
openclaw doctor --fix
openclaw doctor --generate-gateway-token
openclaw security audit
```

If you're ready for automatic remediations:

```bash
openclaw security audit --fix
```

## Baseline This Bundle Assumes

* Gateway is bound to loopback (not public internet)
* Token auth is enabled (replace REPLACE_ME in OPENCLAW_CONFIG_SNIPPET.json5)
* dmPolicy is **pairing** (configure via `openclaw configure` per-channel)
* Logs redact sensitive tool I/O
* Tools run in a sandbox by default

## Operational Checklist

* Verify gateway is not public: `openclaw status` and `openclaw gateway status`
* Ensure you can access the dashboard locally: `openclaw dashboard`
* Do not share agent directories between agents. Each agent keeps OAuth tokens under its own agentDir (auth-profiles.json).
