# OPENCLAW_SETUP_MISTAKES.md

This playbook covers the most common OpenClaw setup failures and how to prevent them.

## 1. Not setting explicit boundaries in config

**Risk**
Vague instructions invite creative behavior and side effects.

**Fix**
Use explicit scope and constraints.
Example: "Scan inbox for emails from approved contacts, flag urgent messages, do not reply without approval."

## 2. Exposing ports publicly without authentication

**Risk**
Binding a gateway/API to public interfaces without auth creates a direct compromise path.

**Fix**
Bind locally by default and use authenticated access paths:
* Loopback-only binding whenever possible
* SSH tunnel or authenticated reverse proxy for remote access

## 3. Running on your daily-driver machine without isolation

**Risk**
Prompt injection or buggy automation can impact personal files and system stability.

**Fix**
Use isolation:
* Dedicated machine, VM, or container
* Principle of least privilege for tools and filesystem access

## 4. Not logging enough

**Risk**
When behavior is unexpected, no logs means no root cause.

**Fix**
Log at least:
* Tool calls and outcomes
* External API calls
* Security events and blocked actions
* Configuration changes over time

## 5. Underestimating token and model costs

**Risk**
Always-on agents can burn usage quickly, especially with short heartbeat intervals.

**Fix**
* Review spend weekly
* Use cheaper models for low-risk tasks
* Keep heartbeat conservative unless needed

## 6. No backup strategy

**Risk**
Losing your configuration means rebuilding behavior and policy from scratch.

**Fix**
* Keep config in git
* Maintain at least one offsite backup
* Test restore at least once

## 7. Granting high permissions too early

**Risk**
Early over-permissioning increases blast radius from mistakes.

**Fix**
Start read-only and escalate gradually after observed reliability.

## 8. No kill switch

**Risk**
Without an immediate stop path, runaway behavior can continue longer than acceptable.

**Fix**
Maintain a remote stop mechanism and test it regularly.

## 9. No resource limits

**Risk**
Loops or bad prompts can consume CPU, memory, and disk until services fail.

**Fix**
Set and monitor:
* CPU limits
* Memory limits
* Disk quotas

## 10. Forgetting the agent learns from workspace context

**Risk**
Sensitive files in workspace can leak into prompts, logs, or summaries.

**Fix**
* Keep secrets out of plaintext files
* Use environment variables and secrets management
* Minimize sensitive data in working directories

## Weekly Safety Review Checklist

* Review logs and security events
* Confirm gateway binding/auth is still correct
* Audit spend and heartbeat settings
* Verify backups are current
* Review permission scope for tools
* Confirm kill switch still works

Owner: Sim
