param(
  [switch]$Fix
)

$ErrorActionPreference = 'Stop'

Write-Host 'Running OpenClaw doctor...' -ForegroundColor Cyan
openclaw doctor --fix

Write-Host 'Running OpenClaw security audit...' -ForegroundColor Cyan
openclaw security audit

if ($Fix) {
  Write-Host 'Applying fixes (openclaw security audit --fix)...' -ForegroundColor Yellow
  openclaw security audit --fix
}

Write-Host 'Done.' -ForegroundColor Green
