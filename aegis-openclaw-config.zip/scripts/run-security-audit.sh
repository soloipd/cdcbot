#!/usr/bin/env bash
set -euo pipefail

FIX="${1:-}"

echo "Running OpenClaw doctor..."
openclaw doctor --fix

echo "Running OpenClaw security audit..."
openclaw security audit

if [[ "$FIX" == "--fix" ]]; then
  echo "Applying fixes (openclaw security audit --fix)..."
  openclaw security audit --fix
fi

echo "Done."
